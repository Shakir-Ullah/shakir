<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateManagementsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('managements', function(Blueprint $table) {
            $table->increments('id');
            $table->string('title');
            $table->string('category');
            $table->string('partner');
            $table->text('descriptoin');
            $table->string('published');
            $table->string('featured');
            $table->float('price');
            $table->text('discount(%)');
            $table->string('file');
            $table->string('thumbnail');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('managements');
    }
}
