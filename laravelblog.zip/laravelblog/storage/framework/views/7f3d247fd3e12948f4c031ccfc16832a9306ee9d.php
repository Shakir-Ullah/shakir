<div class="form-group <?php echo e($errors->has('title') ? 'has-error' : ''); ?>">
    <?php echo Form::label('title', 'Title', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('title', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('title', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('category') ? 'has-error' : ''); ?>">
    <?php echo Form::label('category', 'Category', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::select('category', ['video', 'audio', 'others'], null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('category', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('partner') ? 'has-error' : ''); ?>">
    <?php echo Form::label('partner', 'Partner', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::select('partner', ['spondon', 'rajiv', 'shojib'], null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('partner', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('descriptoin') ? 'has-error' : ''); ?>">
    <?php echo Form::label('descriptoin', 'Descriptoin', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::textarea('descriptoin', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('descriptoin', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('published') ? 'has-error' : ''); ?>">
    <?php echo Form::label('published', 'Published', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('published', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('published', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('featured') ? 'has-error' : ''); ?>">
    <?php echo Form::label('featured', 'Featured', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('featured', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('featured', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('price') ? 'has-error' : ''); ?>">
    <?php echo Form::label('price', 'Price', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::number('price', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('price', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('discount(%)') ? 'has-error' : ''); ?>">
    <?php echo Form::label('discount(%)', 'Discount(%)', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::textarea('discount(%)', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('discount(%)', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('file') ? 'has-error' : ''); ?>">
    <?php echo Form::label('file', 'File', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::file('file', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('file', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('thumbnail') ? 'has-error' : ''); ?>">
    <?php echo Form::label('thumbnail', 'Thumbnail', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::file('thumbnail', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('thumbnail', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<div class="form-group">
    <div class="col-md-offset-4 col-md-4">
        <?php echo Form::submit(isset($submitButtonText) ? $submitButtonText : 'Create', ['class' => 'btn btn-primary']); ?>

    </div>
</div>
