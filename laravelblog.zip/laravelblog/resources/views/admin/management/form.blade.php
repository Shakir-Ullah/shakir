<div class="form-group {{ $errors->has('title') ? 'has-error' : ''}}">
    {!! Form::label('title', 'Title', ['class' => 'col-md-4 control-label']) !!}
    <div class="col-md-6">
        {!! Form::text('title', null, ['class' => 'form-control']) !!}
        {!! $errors->first('title', '<p class="help-block">:message</p>') !!}
    </div>
</div><div class="form-group {{ $errors->has('category') ? 'has-error' : ''}}">
    {!! Form::label('category', 'Category', ['class' => 'col-md-4 control-label']) !!}
    <div class="col-md-6">
        {!! Form::select('category', ['video', 'audio', 'others'], null, ['class' => 'form-control']) !!}
        {!! $errors->first('category', '<p class="help-block">:message</p>') !!}
    </div>
</div><div class="form-group {{ $errors->has('partner') ? 'has-error' : ''}}">
    {!! Form::label('partner', 'Partner', ['class' => 'col-md-4 control-label']) !!}
    <div class="col-md-6">
        {!! Form::select('partner', ['spondon', 'rajiv', 'shojib'], null, ['class' => 'form-control']) !!}
        {!! $errors->first('partner', '<p class="help-block">:message</p>') !!}
    </div>
</div><div class="form-group {{ $errors->has('descriptoin') ? 'has-error' : ''}}">
    {!! Form::label('descriptoin', 'Descriptoin', ['class' => 'col-md-4 control-label']) !!}
    <div class="col-md-6">
        {!! Form::textarea('descriptoin', null, ['class' => 'form-control']) !!}
        {!! $errors->first('descriptoin', '<p class="help-block">:message</p>') !!}
    </div>
</div><div class="form-group {{ $errors->has('published') ? 'has-error' : ''}}">
    {!! Form::label('published', 'Published', ['class' => 'col-md-4 control-label']) !!}
    <div class="col-md-6">
        {!! Form::text('published', null, ['class' => 'form-control']) !!}
        {!! $errors->first('published', '<p class="help-block">:message</p>') !!}
    </div>
</div><div class="form-group {{ $errors->has('featured') ? 'has-error' : ''}}">
    {!! Form::label('featured', 'Featured', ['class' => 'col-md-4 control-label']) !!}
    <div class="col-md-6">
        {!! Form::text('featured', null, ['class' => 'form-control']) !!}
        {!! $errors->first('featured', '<p class="help-block">:message</p>') !!}
    </div>
</div><div class="form-group {{ $errors->has('price') ? 'has-error' : ''}}">
    {!! Form::label('price', 'Price', ['class' => 'col-md-4 control-label']) !!}
    <div class="col-md-6">
        {!! Form::number('price', null, ['class' => 'form-control']) !!}
        {!! $errors->first('price', '<p class="help-block">:message</p>') !!}
    </div>
</div><div class="form-group {{ $errors->has('discount(%)') ? 'has-error' : ''}}">
    {!! Form::label('discount(%)', 'Discount(%)', ['class' => 'col-md-4 control-label']) !!}
    <div class="col-md-6">
        {!! Form::textarea('discount(%)', null, ['class' => 'form-control']) !!}
        {!! $errors->first('discount(%)', '<p class="help-block">:message</p>') !!}
    </div>
</div><div class="form-group {{ $errors->has('file') ? 'has-error' : ''}}">
    {!! Form::label('file', 'File', ['class' => 'col-md-4 control-label']) !!}
    <div class="col-md-6">
        {!! Form::file('file', null, ['class' => 'form-control']) !!}
        {!! $errors->first('file', '<p class="help-block">:message</p>') !!}
    </div>
</div><div class="form-group {{ $errors->has('thumbnail') ? 'has-error' : ''}}">
    {!! Form::label('thumbnail', 'Thumbnail', ['class' => 'col-md-4 control-label']) !!}
    <div class="col-md-6">
        {!! Form::file('thumbnail', null, ['class' => 'form-control']) !!}
        {!! $errors->first('thumbnail', '<p class="help-block">:message</p>') !!}
    </div>
</div>

<div class="form-group">
    <div class="col-md-offset-4 col-md-4">
        {!! Form::submit(isset($submitButtonText) ? $submitButtonText : 'Create', ['class' => 'btn btn-primary']) !!}
    </div>
</div>
