<?php

namespace App\Http\Controllers\Admin;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\Management;
use Illuminate\Http\Request;
use Session;

class ManagementController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        $keyword = $request->get('search');
        $perPage = 25;

        if (!empty($keyword)) {
            $management = Management::where('title', 'LIKE', "%$keyword%")
				->orWhere('category', 'LIKE', "%$keyword%")
				->orWhere('partner', 'LIKE', "%$keyword%")
				->orWhere('descriptoin', 'LIKE', "%$keyword%")
				->orWhere('published', 'LIKE', "%$keyword%")
				->orWhere('featured', 'LIKE', "%$keyword%")
				->orWhere('price', 'LIKE', "%$keyword%")
				->orWhere('discount(%)', 'LIKE', "%$keyword%")
				->orWhere('file', 'LIKE', "%$keyword%")
				->orWhere('thumbnail', 'LIKE', "%$keyword%")
				
                ->paginate($perPage);
        } else {
            $management = Management::paginate($perPage);
        }

        return view('admin.management.index', compact('management'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {
        return view('admin.management.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function store(Request $request)
    {
        
        $requestData = $request->all();
        

if ($request->hasFile('file')) {
    $uploadPath = public_path('/uploads/');

    $extension = $request->file('file')->getClientOriginalExtension();
    $fileName = rand(11111, 99999) . '.' . $extension;

    $request->file('file')->move($uploadPath, $fileName);
    $requestData['file'] = $fileName;
}


if ($request->hasFile('thumbnail')) {
    $uploadPath = public_path('/uploads/');

    $extension = $request->file('thumbnail')->getClientOriginalExtension();
    $fileName = rand(11111, 99999) . '.' . $extension;

    $request->file('thumbnail')->move($uploadPath, $fileName);
    $requestData['thumbnail'] = $fileName;
}

        Management::create($requestData);

        Session::flash('flash_message', 'Management added!');

        return redirect('admin/management');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function show($id)
    {
        $management = Management::findOrFail($id);

        return view('admin.management.show', compact('management'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function edit($id)
    {
        $management = Management::findOrFail($id);

        return view('admin.management.edit', compact('management'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function update($id, Request $request)
    {
        
        $requestData = $request->all();
        

if ($request->hasFile('file')) {
    $uploadPath = public_path('/uploads/');

    $extension = $request->file('file')->getClientOriginalExtension();
    $fileName = rand(11111, 99999) . '.' . $extension;

    $request->file('file')->move($uploadPath, $fileName);
    $requestData['file'] = $fileName;
}


if ($request->hasFile('thumbnail')) {
    $uploadPath = public_path('/uploads/');

    $extension = $request->file('thumbnail')->getClientOriginalExtension();
    $fileName = rand(11111, 99999) . '.' . $extension;

    $request->file('thumbnail')->move($uploadPath, $fileName);
    $requestData['thumbnail'] = $fileName;
}

        $management = Management::findOrFail($id);
        $management->update($requestData);

        Session::flash('flash_message', 'Management updated!');

        return redirect('admin/management');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function destroy($id)
    {
        Management::destroy($id);

        Session::flash('flash_message', 'Management deleted!');

        return redirect('admin/management');
    }
}
